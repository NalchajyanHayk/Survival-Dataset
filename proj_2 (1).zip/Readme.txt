we initially had another plans for preprocessing and with that file we had higher results 
but there were many errors that kept occuring and we couldnt  resolve them . Thats why we didnt do the steps that we wanted and went with simpler path. 
intially we wanted to do this

if sth that has the suffix ('first', 'last', 'highest', 'lowest', 'median') and has more thatn 30 percent Nan we drop thta col and all of the cols that are related to that (have the same prefix and other suffixes from here) . 


that code is in fail.py you can check it out too )))
Our team members :

Team 3 -  Ashot, Hayk N.


p.s. by the way when creting requirements.txt I used this command so idk if i did the right thing or not 

pip freeze > requirements.txt


a lot of the code was new to me and there might be some parts that wont work well or will throw exceptions and cause errors so please approach with understanding and a lot of nerves ))