import pandas as pd

file_path = "Survival_dataset.csv"
df = pd.read_csv(file_path)
df_modified = df.copy()
excluded_features = ['Length_of_stay', 'SAPS-I', 'SOFA', 'Survival', 'recordid']

df_modified = df_modified.drop(columns=excluded_features)
selected_prefixes = set()

for column in df.columns:
    if column.endswith(('first', 'last', 'highest', 'lowest', 'median')):
        if df[column].isnull().mean() > 0.3:
            prefix = column.rsplit('_', 1)[0]
            if prefix not in selected_prefixes:
                columns_to_drop = [col for col in df.columns if col.startswith(prefix)]
                df_modified = df_modified.drop(columns=columns_to_drop)
                selected_prefixes.add(prefix)
    else:
        if df[column].isnull().mean() > 0.3:
            df_modified = df_modified.drop(columns=[column])
print('Number of columns before deleting Nans: ', len(df.columns))
print('Number of columns after deleting Nans: ', len(df_modified.columns))
# drop all the Nans of Gender because we just cant make up value for sth like this
df_modified = df_modified.dropna(subset=['Gender'])
# let's check if there are any values other than 0 or 1 before we get to OHE
gender_values = set(df_modified['Gender'])

if gender_values - {0, 1}:
    print("warning: Gender can only have values 0 or 1.")

numerical_columns = df.select_dtypes(include='number').columns
categorical_columns = df.select_dtypes(exclude='number').columns

df[numerical_columns] = df[numerical_columns].fillna(df[numerical_columns].median())
for column in categorical_columns:
    mode = df[column].mode().iloc[0]
    df[column].fillna(mode)

output_file_path = 'Survival_dataset_final_1.csv'
df_modified.to_csv(output_file_path, index=False)