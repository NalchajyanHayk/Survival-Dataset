from sklearn.ensemble import RandomForestClassifier, StackingClassifier, GradientBoostingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score, f1_score

class Model:
    def __init__(self, scaler=StandardScaler()):
        """
       model initialization

        we used stacking classifier in which we used random forest then svm then the final estimator was gradient boost
        """
        base_models = [
            ('GB',GradientBoostingClassifier(random_state=42) ),
            ('svm', SVC(probability=True, random_state=42)),
        ]

        self.stacking_model = StackingClassifier(estimators=base_models,
                                                 final_estimator=RandomForestClassifier(n_estimators=200, random_state=42))
        self.scaler = scaler

    def fit(self, X_train, y_train):

        X_train_scaled = self.scaler.fit_transform(X_train)
        self.stacking_model.fit(X_train_scaled, y_train)

    def predict(self, X_test):

        X_test_scaled = self.scaler.transform(X_test)
        return self.stacking_model.predict(X_test_scaled)

    def predict_proba(self, X_test):

        X_test_scaled = self.scaler.transform(X_test)
        return self.stacking_model.predict_proba(X_test_scaled)[:, 1]

    def evaluate(self, X_test, y_test):
        X_test_scaled = self.scaler.transform(X_test)

        y_pred = self.stacking_model.predict(X_test_scaled)
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred)
        recall = recall_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)

        print('Accuracy: ',accuracy)
        print('Precision ',precision)
        print('Recall: ', recall)
        print('F1 Score:' , f1)

        c_matrix = confusion_matrix(y_test, y_pred)
        tn, fp, fn, tp = c_matrix.ravel()

        print('Confusion Matrix:')
        print(c_matrix)
        print('True Positives: ', tp)
        print('True Negatives: ', tn)
        print('False Positives: ', fp)
        print('False Negatives:', fn)
