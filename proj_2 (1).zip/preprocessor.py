import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import StandardScaler
#this is a somewhat simpler version because of some errors that I wrote about in the readme file
class Preprocessor(BaseEstimator, TransformerMixin):
    def __init__(self, numerical_strategy='median', drop_threshold=0.3):
        self.numerical_strategy = numerical_strategy
        self.drop_threshold = drop_threshold
        self.scaler = StandardScaler()
        self.numerical_columns = None

    def fit(self, X):
        df = X.copy()

        self.numerical_columns = df.select_dtypes(include='number').columns

        # dealing with missing values

        if self.numerical_strategy == 'median':
            self.median_values = df[self.numerical_columns].median()
        elif self.numerical_strategy == 'mean':
            self.mean_values = df[self.numerical_columns].mean()

        #fittinh
        self.scaler.fit(df[self.numerical_columns])

        #if these exist we will drop them because they shouldn be in data
        excluded_features = ['Length_of_stay', 'SAPS-I', 'SOFA', 'Survival', 'recordid']
        existing_columns = set(df.columns)
        excluded_columns = set(excluded_features).intersection(existing_columns)
        df = df.drop(columns=excluded_columns)

        return self

    def transform(self, X):
        df = X.copy()

        # dealing with missing values
        if self.numerical_strategy == 'median':
            df[self.numerical_columns] = df[self.numerical_columns].fillna(self.median_values)
        elif self.numerical_strategy == 'mean':
            df[self.numerical_columns] = df[self.numerical_columns].fillna(self.mean_values)

        # scaling
        df[self.numerical_columns] = self.scaler.transform(df[self.numerical_columns].values)

        return df
