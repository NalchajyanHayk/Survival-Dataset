import argparse
import pandas as pd
from joblib import dump, load
from model import Model
from preprocessor import Preprocessor
import json

class Pipeline:
    def __init__(self):
        self.preprocessor = None
        self.model = Model()

    def run(self, data_path, test=False):
        if not test:
            df = pd.read_csv(data_path)

            X = df.drop(columns=['In-hospital_death'])
            y = df['In-hospital_death']

            from sklearn.model_selection import train_test_split
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

            #using the preprocessor
            self.preprocessor = Preprocessor()
            self.preprocessor.fit(X_train)
            X_train_processed = self.preprocessor.transform(X_train)
            self.model.fit(X_train_processed, y_train)

            X_test_processed = self.preprocessor.transform(X_test)
            self.model.evaluate(X_test_processed, y_test)

            #saving with jobllib
            dump(self.preprocessor, 'preprocessor.joblib')
            dump(self.model, 'model.joblib')

        else:
            X_test = pd.read_csv(data_path)
            self.preprocessor = load('preprocessor.joblib')
            self.model = load('model.joblib')
            X_test_processed = self.preprocessor.transform(X_test)
            #creating oredictions and saving them
            predictions = {
                'predict_probas': list(self.model.predict_proba(X_test_processed)),
                'threshold': 0.5
            }

            with open('predictions.json', 'w') as file:
                json.dump(predictions, file)




if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--data_path", type=str, default="Survival_dataset.csv", help="Your path to the data file.")
    parser.add_argument("--test", action="store_true", help="Test mode or not?")

    args = parser.parse_args()

    pipeline = Pipeline()
    pipeline.run(args.data_path, test=args.test)
